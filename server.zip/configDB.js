export const configDB={
        host     : 'localhost',
        user     : 'root',
        password : 'kam',
        database : 'todos',
        multipleStatements: true // Engedélyezzük a több utasítást
}

